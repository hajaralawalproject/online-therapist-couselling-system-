-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2023 at 12:50 PM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `otcs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'hajara', 'hajara123');

-- --------------------------------------------------------

--
-- Table structure for table `patent_register`
--

CREATE TABLE `patent_register` (
  `id` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `secoundname` text NOT NULL,
  `phonenumber` varchar(15) NOT NULL,
  `email` varchar(20) NOT NULL,
  `age` int(80) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `maritalstatus` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `regtime` varchar(10) NOT NULL,
  `picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `patent_register`
--

INSERT INTO `patent_register` (`id`, `firstname`, `secoundname`, `phonenumber`, `email`, `age`, `gender`, `maritalstatus`, `password`, `regtime`, `picture`) VALUES
(4, 'hajiya', 'adamu', '08133671568', 'hajjobounty@yahoo.co', 0, 'male', 'single', '12345', '12:00', 'jhgh'),
(5, 'aih', 'bih', '086565776', 'aih@beti.org', 27, 'male', 'single', 'aih@beti.org', '', 'nehhh.png');

-- --------------------------------------------------------

--
-- Table structure for table `therapy_register`
--

CREATE TABLE `therapy_register` (
  `id` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `secoundname` text NOT NULL,
  `phonenumber` varchar(15) NOT NULL,
  `email` varchar(20) NOT NULL,
  `age` int(80) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `maritalstatus` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `regtime` varchar(10) NOT NULL,
  `picture` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `therapy_register`
--

INSERT INTO `therapy_register` (`id`, `firstname`, `secoundname`, `phonenumber`, `email`, `age`, `gender`, `maritalstatus`, `password`, `regtime`, `picture`) VALUES
(4, 'hajiya', 'adamu', '08133671568', 'hajjobounty@yahoo.co', 0, 'male', 'single', '12345', '12:00', 'jhgh'),
(5, 'AbdurrAhman Ih', 'bih', '08105805612', 'kimiyyasciece@gmail.', 27, 'male', 'single', 'aih', '10/10/2010', 'aih.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_chat`
--

CREATE TABLE `user_chat` (
  `id` int(6) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_chat4`
--

CREATE TABLE `user_chat4` (
  `id` int(6) NOT NULL,
  `message` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_chat4`
--

INSERT INTO `user_chat4` (`id`, `message`) VALUES
(1, '<span class=''linker_ms'' onclick=''loadlink()''>Meeting scheduled. Date: 2022-11-28T04:55 Time:click to'),
(2, 'Therapist:  mnjnm,'),
(3, 'ME (hajiya):  mnjnm,'),
(4, 'ME (hajiya):  hello sir'),
(5, 'Therapist:  Meeting scheduled. Date: 2022-11-28T04:55 Time:click to'),
(6, '<span class=''linker_ms'' onclick=''loadlink()''>Meeting scheduled. Date:  Time:click to proceed.</span>');

-- --------------------------------------------------------

--
-- Table structure for table `user_chat5`
--

CREATE TABLE `user_chat5` (
  `id` int(6) NOT NULL,
  `message` varchar(100) NOT NULL,
  `linkage` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_chat5`
--

INSERT INTO `user_chat5` (`id`, `message`, `linkage`) VALUES
(1, 'ME (aih):  hello', ''),
(2, '<span class=''linker_ms'' onclick=''loadlink()''>Meeting scheduled. Date: 2022-11-17T08:45 Time:click to', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patent_register`
--
ALTER TABLE `patent_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `therapy_register`
--
ALTER TABLE `therapy_register`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_chat`
--
ALTER TABLE `user_chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_chat4`
--
ALTER TABLE `user_chat4`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_chat5`
--
ALTER TABLE `user_chat5`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `patent_register`
--
ALTER TABLE `patent_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `therapy_register`
--
ALTER TABLE `therapy_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `user_chat`
--
ALTER TABLE `user_chat`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_chat4`
--
ALTER TABLE `user_chat4`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_chat5`
--
ALTER TABLE `user_chat5`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
