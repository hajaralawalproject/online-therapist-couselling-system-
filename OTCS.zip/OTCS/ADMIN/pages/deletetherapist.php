<?php
       include "connection.php";
   echo     $ID = $_GET['id'];

        $DELETE = "DELETE FROM `therapy_register` WHERE id= $ID";
       
        $DELETION = mysqli_query($connection, $DELETE);
        if ($DELETION) {
            # code...
                ?>
                <script>
                    window.location.href="therapistsAccount.php";
                </script>
                <?php
        }
        else {
            echo "cant be";
        }
?>