<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<?php
		include "connection.php";

	if (isset($_POST['register']) ) {


	$FIRTNAME =	$_POST['firstname'];
	$SECOUNDNAME =	$_POST['secoundname'];
	$PHONENUMBER =	$_POST['phonenumber'];
	$EMAIL =	$_POST['email'];
	$AGE =	$_POST['age'];
	$GENDER =	$_POST['gender'];
	$MARITALSTATUS =	$_POST['maritalstatus'];
	$PASSWORD =	$_POST['comfirmpassword'];
	$CONFARMPASSWORD =	$_POST['password'];
	$REGTIME =	$_POST['regtime'];
	$PICTURE =	$_POST['picture'];
	if (empty($PASSWORD) || empty($CONFARMPASSWORD) ) {
    	echo "<script>alert('connection registration is succesful')</script>";
		# code...
	}
	else{
			if($PASSWORD != $CONFARMPASSWORD){
    	echo "<script>alert('connection registration is succesful')</script>";

			}
			else{

			$insertion ="INSERT INTO `patent_register`(`firstname`, `secoundname`, `phonenumber`, `email`, `age`, `gender`, `maritalstatus`, `password`, `regtime`, `picture`) VALUES ('$FIRTNAME','$SECOUNDNAME','$PHONENUMBER','$EMAIL','$AGE','$GENDER','$MARITALSTATUS','$PASSWORD','$REGTIME','$PICTURE')";
			$Q = mysqli_query($connection, $insertion);
			if ($Q) {
    	echo "<script>alert('connection registration is succesful')</script>";
				
			}
			else{
    	echo "<script>alert('connection fail')</script>";

			}

		# code...
	}
}}

		else{
		echo "<script>alert('cant save data')</script>";	
		}
			
			
	


		
	?>
	<nav class="nav">
		<img src="logo/therapy.jpg" alt="" >
	</nav>

	<div class="parent">
		<div class="form-bg">
			<div class="form-bar">
				<form action="index.php" method="post">
				<center>
				<div class="passport-container"><div class="passport">
					<img src="" alt="" id="passimg">
					<input type="file" name="picture" onchange="document.getElementById('passimg').src = window.URL.createObjectURL(this.files[0]);">
					 </div>
				</div>
				<div class="other-iputs">
					<div class="input-parent">
				<input type="text" name="firstname" placeholder="firstname" required>
				<input type="text" name="secoundname" placeholder="secoundname" required>
				<input type="text" name="phonenumber" placeholder="phonenumber" required>
				<input type="text" name="email" placeholder="email" required>
				<input type="text" name="age" placeholder="age" required>
				<select name="gender">
					<option value="male">Gender:   Male</option>
					<option value="female">Gender:   Female</option>
				</select>
				<input type="text" name="maritalstatus" placeholder="maritalstatus" required>
				<input type="text" name="regtime" placeholder="regtime" required>
				<input type="text" name="password" placeholder="password" required>
				<input type="text" name="comfirmpassword" placeholder="confarm password" required>
				<input type="submit" name="register" value="register">
			</div>
				</div>
					</center>
				</form>
			</div>
		</div>
	</div>
	<script>
	document.getElementById('passimg').src = window.URL.createObjectURL(this.files[0]);
	</script>
</body>
</html>