<?php
 session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <title>
    OTCS
  </title>
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" />
  <!-- Nucleo Icons -->
  <link href="assets/css/nucleo-icons.css" rel="stylesheet" />
  <link href="assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- Font Awesome Icons -->
  <script src="https://kit.fontawesome.com/42d5adcbca.js" crossorigin="anonymous"></script>
  <link href="../assets/css/nucleo-svg.css" rel="stylesheet" />
  <!-- CSS Files -->
  <link id="pagestyle" href="../assets/css/argon-dashboard.css?v=2.0.4" rel="stylesheet" />

    <style type="text/css">
      .mb-3 input{
        width: 300px;
        height: 40px;
        text-align: center;
        margin-top: 8px;
      }
    </style>
</head>

<body class="">
         
  <div class="container position-sticky z-index-sticky top-0">
    <div class="row">
      <div class="col-12">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg blur border-radius-lg top-0 z-index-3 shadow position-absolute mt-4 py-2 start-0 end-0 mx-4">
             </nav>
        <!-- End Navbar -->
      </div>
    </div>
  </div>
  <main class="main-content  mt-0">
    <section>
      <div class="page-header min-vh-100">
        <div class="container">
          <div class="row">
            <div class="col-xl-4 col-lg-5 col-md-7 d-flex flex-column mx-lg-0 mx-auto">
              <div class="card card-plain">
                 <div class="card-body">
                  <form role="form" enctype="multipart/form-data" action="register.php" method="post">
                    
                    <div class="mb-3">
                      <div id="ppbg" style="width: 300px; height: 300px;
                      display: flex-box; justify-content: center; align-items: center;
                      border: solid 2px black; border-radius: 10px; ">
                        <img src="" style="position: relative; border: none;
                        width: 300px; height: 300px; background: center no-repeat;"  id="passport" >

                        <input  required type="file" name="pictures" style="position: relative;
                        width: 300px; margin-left: 50px; margin-top: 5px;" onchange="document.getElementById('passport').src = window.URL.createObjectURL(this.files[0])">
                        
                      </div>
                    </div>
                    <br>
                    <br>
                    <div class="mb-3">
                      <input  required type="text" name="firstname" class="form-control form-control-lg" placeholder="firstname" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="text" name="secoundname" class="form-control form-control-lg" placeholder="second name" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="text" name="phonenumber" class="form-control form-control-lg" placeholder="phonenumber" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="email" name="email" class="form-control form-control-lg" placeholder="email" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="text" name="age" class="form-control form-control-lg" placeholder="age" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="text" name="gender" class="form-control form-control-lg" placeholder="gender" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="text" name="maritalstatus" class="form-control form-control-lg" placeholder="marital status" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="password" name="password" class="form-control form-control-lg" placeholder="create password" aria-label="Email">
                    </div>
                    <div class="mb-3">
                      <input  required type="password" name="password2" class="form-control form-control-lg" placeholder="retype password" aria-label="Email">
                    </div>
                    
                    <div class="form-check form-switch">
                      <input class="form-check-input" type="checkbox" id="rememberMe">
                      <label class="form-check-label" for="rememberMe">Remember me</label>
                    </div>
                    <div class="text-center">
                      <button type="submit" name="REGISTER" class="btn btn-lg btn-primary btn-lg w-100 mt-4 mb-0" 

                      style="width: 300px; height: 200px;
                      height: 40px;
                      background: blue; 
                      border: none;
                      border-radius: 5px;
                      color: whitesmoke;
                      " 
                      >Register</button>
                    </div>
                   
                  </form>
                </div>
                <div class="card-footer text-center pt-0 px-lg-2 px-1">
                  </p>
                </div>
              </div>
            </div>
            <div class="col-6 d-lg-flex d-none h-100 my-auto pe-0 position-absolute top-0 end-0 text-center justify-content-center flex-column">
              <div class="position-relative bg-gradient-primary h-100 m-3 px-7 border-radius-lg d-flex flex-column justify-content-center overflow-hidden" style="background: blue;
              margin: 0px;
              padding: 0px;

              ">
                <h4  style="text-align: center;
                color: whitesmoke ; text-transform: uppercase;
                font-family: sans-serif;
                margin-top: 10px;
                padding-top: 10px;" class="mt-5 text-white font-weight-bolder position-relative">Online Counselling System</h4>

                <p class="text-white position-relative" style="text-align: center;
                color: whitesmoke;
                letter-spacing: 5px;
                font-size: 14px;">By Hajara AlQalam University Katsina, Katsina state</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </main>
  <!--   Core JS Files   -->
  <script src="../assets/js/core/popper.min.js"></script>
  <script src="../assets/js/core/bootstrap.min.js"></script>
  <script src="../assets/js/plugins/perfect-scrollbar.min.js"></script>
  <script src="../assets/js/plugins/smooth-scrollbar.min.js"></script>
  <script>
    var win = navigator.platform.indexOf('Win') > -1;
    if (win && document.querySelector('#sidenav-scrollbar')) {
      var options = {
        damping: '0.5'
      }
      Scrollbar.init(document.querySelector('#sidenav-scrollbar'), options);
    }
  </script>
  <!-- Github buttons -->
  <script async defer src="https://buttons.github.io/buttons.js"></script>
  <!-- Control Center for Soft Dashboard: parallax effects, scripts for the example pages etc -->
  <script src="../assets/js/argon-dashboard.min.js?v=2.0.4"></script>
  <?php
    
        include 'connection.php';

        if (isset($_POST['REGISTER'])) {
            # code...
          
          $firstname = $_POST['firstname'];
          $secoundname = $_POST['secoundname'];
          $phonenumber = $_POST['phonenumber'];
          $email = $_POST['email'];
          $age = $_POST['age'];
          $gender = $_POST['gender'];
          $maritalstatus = $_POST['maritalstatus'];
          $password = $_POST['password'];
          $password2 = $_POST['password2'];
          $picturename =  $_FILES['pictures']['name'];
          $picturefile =  $_FILES['pictures']['tmp_name'];
          #$picturFile = $_FILES['picture']['name'];
          $location ="passports/";
           
          $_SESSION['email_generator'] = $email;
          $INSERTION ="INSERT INTO `therapy_register`(`firstname`, `secoundname`, `phonenumber`, `email`, `age`, `gender`, `maritalstatus`, `password`,`picture`) 
          VALUES ('$firstname','$secoundname','$phonenumber','$email','$age','$gender','$maritalstatus','$password','$picturename')";
          
                if ($password == $password2) {
                  // code...
                 $QUERY = mysqli_query($connection, $INSERTION);
                    if ($QUERY) {
                      if(move_uploaded_file($picturefile, 'passports/'.$picturename)){
                        ?>
                        <script>
                          alert('You have bess registered. let logIn');
                          setTimeout(() => {
                            window.location.href="sign-in.php";
                          }, 1000);
                        </script>
                        <?php
                    }
                    else{
                      echo "<script> alert('cant be uploaded');</script>";

                    } }
                    else{

                    echo "<script> alert('cant be resgistered');</script>";
                }}
                else{
            echo "<script>alert('Wrong Username or password');</script>";
                }
              }?>
</body>

</html>