<?php
	$username="root";
	$host="localhost";
	$network_password="";
	$data_base="otcs";
    $connection=mysqli_connect($host,$username,$network_password,$data_base);
    if (!$connection) {
    	# code...
    	echo "<script>alert('connection fail')</script>";
    }

?>