<script type="text/javascript">
	setTimeout(() => {
        window.location.href ="pages/sign-in.php";
    }, 100);
</script>