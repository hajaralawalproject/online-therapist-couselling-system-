<?php
$connection = mysqli_connect("localhost","root","", "otcos");

    if (!$connection) {
        # code...
        echo "<script>alert('Cant establish connection to DB engine');</script>";
    }

    


?>