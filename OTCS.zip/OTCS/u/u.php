<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>

<form action="u.php" method="post" enctype="multipart/form-data">
	<input type="file" name="passport"><br>
	<input type="submit" name="submit">
</form>
<?php 

	if (isset($_POST['submit'])) {
			// code...
	$NAME =	$_FILES['passport']['name'];
	$PASS =	$_FILES['passport']['tmp_name'];
	$PIC = "pic/";


	if (move_uploaded_file($_FILES['passport']['tmp_name'], 'pic/'.$NAME)) {

		echo "<script>alert('done');</script>";

		}
		else{
			echo "<script>alert('fail');</script>";

		} }	

		else{
			echo "<script>alert('fail');</script>";
		}

 ?>
</body>
</html>